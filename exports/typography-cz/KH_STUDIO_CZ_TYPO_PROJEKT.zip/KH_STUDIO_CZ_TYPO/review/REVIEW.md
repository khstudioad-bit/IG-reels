# Kontrola české typografické verze

Celá dodaná reference (8,56 s) byla prohlédnuta po časové ose, včetně závěrečného loga. Převzatý princip je typografické psaní na papíru a rychlé střídání rolí. Nová verze má vlastní české texty, papírovou texturu, sazbu, zvuk a identitu KH Studio.

Služby jsou přizpůsobeny UGC: nápad, scénář, UGC obsah, střih a titulky. Výsledek netvrdí správu sociálních sítí, obecné marketingové služby ani měřené výsledky. Závěrečný podpis je KH/STUDIO®.

Před renderem byly prohlédnuty snímky 0, 16, 38, 66, 92, 112, 138, 160, 185, 220, 240, 266 a 287; také cover. Sazba drží polohu řádku i při odkrývání znaků. Texty s diakritikou se neořezávají. Zvuk psaní byl zesílen o přibližně 5,5 dB, aby zůstal slyšitelný při zachované špičkové rezervě.

Finální MP4: H.264 / yuv420p / BT.709, 1080 × 1920, 30 fps, 288 snímků, 9,600 s obrazové stopy a AAC. Kompletní dekódování FFmpeg prošlo bez chyby. Cover je 1080 × 1350. Finální zakódované snímky byly ověřeny přes všechny role a koncový podpis. TypeScript prošel.
