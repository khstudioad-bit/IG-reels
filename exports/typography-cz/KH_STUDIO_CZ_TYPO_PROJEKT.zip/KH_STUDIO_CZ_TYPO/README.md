# KH Studio — český typografický Reel

Krátká typografická reklama podle dodané reference: papírové pozadí, psaný text, rychlé střídání slov a závěrečný podpis KH Studio. Texty představují aktuální UGC služby studia.

## Spuštění

Node.js 20+ a npm. Obrazové i zvukové podklady jsou součástí projektu.

```sh
npm ci
npm run dev
npm run check
npm run render
npm run cover
```

Výstupy:
- `out/KH_STUDIO_CZ_TYPO.mp4`: 1080 × 1920, 30 fps, 288 snímků, 9,6 s, H.264/AAC, BT.709.
- `out/KH_STUDIO_CZ_TYPO_COVER.png`: 1080 × 1350, cover 4:5.

`CHROME_PATH` může vybrat vlastní prohlížeč. V cloudovém prostředí se automaticky detekuje `/usr/bin/chromium`, jinde Remotion použije svůj podporovaný prohlížeč.

## Text a střih

- 0–47: „Vaše značka. Náš obsah.“
- 48–83: „Váš UGC tým.“
- 84–104: „NÁPAD.“
- 105–125: „SCÉNÁŘ.“
- 126–149: „UGC OBSAH.“
- 150–170: „STŘIH.“
- 171–191: „TITULKY.“
- 192–245: „Od nápadu po hotovou reklamu.“
- 246–287: podpis KH/STUDIO®.

Texty a jejich přesné hranice jsou v `copy.json`. Animace a sazba jsou v `src/reel.tsx`. Řádky při odkrývání drží pevnou polohu; délka rozepsaného slova nemění centrování. Diakritika je zachována. Zvukové klepnutí odpovídá odhalenému znaku a rychlé výměně služby.

## Podklady

Papír je vlastní procedurální textura, zvuky byly vytvořeny z šumu a oscilátorů. Žádné obrazové snímky, původní cizí logo ani zvuková stopa reference nejsou ve výsledku použity. Inter Tight má SIL Open Font License v `public/fonts/OFL.txt`.

Běžný render potřebuje pouze Node.js. Pro regenerování papíru a zvuku po změně textů nainstalujte Python a knihovny z `requirements-assets.txt`, poté spusťte `npm run assets`.

Před renderem byly zkontrolovány snímky přes celou časovou osu a cover. V nové české verzi zůstaly pouze činnosti odpovídající službám KH Studio: nápad, scénář, UGC obsah, střih a titulky.
