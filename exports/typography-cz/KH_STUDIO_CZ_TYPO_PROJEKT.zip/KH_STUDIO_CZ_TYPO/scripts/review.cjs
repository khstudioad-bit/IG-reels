const {bundle}=require('@remotion/bundler');
const {openBrowser,selectComposition,renderStill}=require('@remotion/renderer');
const fs=require('fs'),path=require('path');
(async()=>{
 const tag=process.argv[2]||'pass1';const out=path.resolve('review',tag);fs.mkdirSync(out,{recursive:true});
 const url=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});
 const executable=process.env.CHROME_PATH||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
 const browser=await openBrowser('chrome',{browserExecutable:executable});
 try{
 for(const [id,frames] of [['KHTypeCZ',[0,16,38,66,92,112,138,160,185,220,240,266,287]],['KHTypeCover',[0]]]){
  const comp=await selectComposition({serveUrl:url,id,puppeteerInstance:browser});
  for(const frame of frames){await renderStill({serveUrl:url,composition:comp,frame,output:path.join(out,`${id}-${frame}.jpg`),imageFormat:'jpeg',jpegQuality:90,puppeteerInstance:browser});console.log(`${id} ${frame}`)}
 }
 }finally{await browser.close({silent:true})}
})().catch(e=>{console.error(e);process.exit(1)});
