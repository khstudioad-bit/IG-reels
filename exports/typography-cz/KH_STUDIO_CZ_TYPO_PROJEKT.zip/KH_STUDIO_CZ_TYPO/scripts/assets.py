from pathlib import Path
import json,wave,numpy as np
from PIL import Image,ImageDraw,ImageFilter
from scipy.ndimage import zoom,gaussian_filter
root=Path(__file__).resolve().parents[1];pub=root/'public';cfg=json.loads((root/'copy.json').read_text());rng=np.random.default_rng(131)
h,w=1920,1080
# An original procedural paper substrate, not a frame taken from the reference.
cloud=np.zeros((h,w),dtype=float)
for gh,gw,amp in [(9,6,1.6),(25,16,1.0),(70,42,.45)]:
 layer=zoom(rng.normal(size=(gh,gw)),(h/gh,w/gw),order=3)[:h,:w]
 cloud+=layer*amp
fold=Image.new('L',(w,h),128);d=ImageDraw.Draw(fold)
for _ in range(95):
 x=float(rng.uniform(-40,w));y=float(rng.uniform(-40,h));angle=rng.uniform(0,np.pi*2);length=rng.uniform(45,230)
 pts=[]
 for k in range(6):
  a=k/5;pts.append((x+np.cos(angle)*length*a+np.sin(a*np.pi)*rng.uniform(-14,14),y+np.sin(angle)*length*a+np.sin(a*np.pi)*rng.uniform(-14,14)))
 d.line([(xx+2,yy+2) for xx,yy in pts],fill=105,width=2)
 d.line(pts,fill=151,width=2)
creases=np.asarray(fold.filter(ImageFilter.GaussianBlur(1.2))).astype(float)-128
shade=cloud+creases*.23+rng.normal(0,.48,(h,w))
base=np.array([244,243,239],dtype=float)
a=np.clip(base[None,None,:]+shade[:,:,None],0,255).astype('uint8')
Image.fromarray(a).save(pub/'paper.png')
# Frame-accurate original typing taps and dry word-change accents.
sr=48000;dur=cfg['durationFrames']/cfg['fps'];t=np.arange(round(dur*sr))/sr;out=np.zeros_like(t)
def tap(at,level=.10):
 q=t-at;m=(q>=0)&(q<.042);z=q[m];noise=rng.normal(size=len(z))
 click=.6*noise*np.exp(-z*180)+.4*np.sin(2*np.pi*1050*z)*np.exp(-z*160)
 out[m]+=level*click
for group in ['opening','team','summary']:
 for line in cfg[group]:
  n=len(line['text']);initial=line.get('initial',0)
  for k in range(initial+1,n+1):
   if line['text'][k-1].isspace():continue
   f=line['start']+(line['end']-line['start'])*(k-initial)/max(1,n-initial)
   tap(f/cfg['fps'],.10+rng.uniform(-.018,.018))
for r in cfg['roles']:
 at=r['from']/cfg['fps'];tap(at,.25)
 q=t-at;m=(q>=0)&(q<.11);z=q[m]
 out[m]+=.13*np.sin(2*np.pi*(95*z+1.2*(1-np.exp(-z*50))))*np.exp(-z*42)
logo=cfg['logoFrom']/cfg['fps'];tap(logo,.22)
q=t-logo;m=(q>=0)&(q<.22);z=q[m];out[m]+=.09*np.sin(2*np.pi*220*z)*np.exp(-z*18)
out=np.tanh(out)*1.60;out*=np.clip((dur-t)/.12,0,1)
st=np.stack([out,np.roll(out,5)*.98],axis=1)
with wave.open(str(pub/'sound.wav'),'wb') as f:
 f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((np.clip(st,-.98,.98)*32767).astype('<i2').tobytes())
print('Original paper texture and 9.6-second frame-aligned typing sound prepared.')
