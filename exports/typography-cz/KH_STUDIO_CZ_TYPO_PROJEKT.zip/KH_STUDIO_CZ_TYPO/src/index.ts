import {registerRoot} from 'remotion';
import {Root} from './reel';
registerRoot(Root);
