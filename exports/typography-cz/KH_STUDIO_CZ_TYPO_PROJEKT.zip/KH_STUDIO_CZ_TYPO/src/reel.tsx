import React from 'react';
import {AbsoluteFill,Audio,Composition,Easing,Img,interpolate,staticFile,useCurrentFrame} from 'remotion';
import copy from '../copy.json';
const INK='#111315',CREAM='#F4F3EF',LIME='#D5FF70';
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const ease=Easing.bezier(.22,1,.36,1);
const ramp=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{...clamp,easing:ease});
const Fonts=()=> <style>{`@font-face{font-family:KH;src:url('${staticFile('fonts/InterTight.ttf')}');font-weight:100 900}*{box-sizing:border-box}`}</style>;
const Paper=()=> <AbsoluteFill style={{background:CREAM}}><Img src={staticFile('paper.png')} style={{width:'100%',height:'100%',objectFit:'cover'}}/></AbsoluteFill>;
type Line={text:string;start:number;end:number;initial:number};
const Typed:React.FC<{line:Line;size:number;nextStart?:number}>=({line,size,nextStart=10000})=>{
 const f=useCurrentFrame();const chars=Array.from(line.text);const n=Math.floor(interpolate(f,[line.start,line.end],[line.initial,chars.length],clamp));
 const show=f>=line.start;const cursor=show&&f<Math.min(line.end+5,nextStart);
 return <div style={{fontSize:size,fontWeight:760,lineHeight:1.18,letterSpacing:-size*.035,whiteSpace:'nowrap',textAlign:'center'}}><span style={{position:'relative',display:'inline-block'}}><span style={{visibility:'hidden'}}>{line.text}</span><span style={{position:'absolute',left:0,top:0}}>{show?chars.slice(0,n).join(''):''}{cursor&&<span style={{display:'inline-block',height:size*.78,width:3,background:INK,marginLeft:5,verticalAlign:'-.04em'}}/>}</span></span></div>
};
const Center:React.FC<{children:React.ReactNode;opacity?:number;y?:number}>=({children,opacity=1,y=0})=><div style={{position:'absolute',left:70,right:70,top:'50%',transform:`translateY(calc(-50% + ${y}px))`,textAlign:'center',opacity}}>{children}</div>;
const Logo:React.FC<{size?:number}>=({size=112})=><div style={{fontSize:size,fontWeight:800,lineHeight:1.08,letterSpacing:-size*.04,whiteSpace:'nowrap'}}>KH<span style={{color:LIME,margin:'0 .045em'}}>/</span>STUDIO<span style={{fontSize:'.3em',verticalAlign:'super',letterSpacing:0}}>®</span></div>;
export const KHTypeCZ=()=>{
 const f=useCurrentFrame();const role=copy.roles.find(r=>f>=r.from&&f<r.to);
 return <AbsoluteFill style={{color:INK,fontFamily:'KH, sans-serif',overflow:'hidden'}}><Fonts/><Paper/>
 {f<48&&<Center opacity={1-ramp(f,45,48)}>{copy.opening.map((line,i)=><Typed key={line.text} line={line} size={108} nextStart={copy.opening[i+1]?.start}/>)}</Center>}
 {f>=48&&f<84&&<Center opacity={1-ramp(f,81,84)}>{copy.team.map((line,i)=><Typed key={line.text} line={line} size={i===0?94:121} nextStart={copy.team[i+1]?.start}/>)}</Center>}
 {role&&<Center y={(1-ramp(f,role.from,role.from+5))*4}><div style={{fontSize:role.text.length>8?102:115,fontWeight:800,lineHeight:1.15,letterSpacing:-2.7,transform:`scale(${interpolate(f,[role.from,role.from+6],[.976,1],{...clamp,easing:ease})})`}}><span style={{display:'inline-block',position:'relative'}}>{role.text==='UGC OBSAH.'&&<span style={{position:'absolute',left:-8,right:-8,bottom:7,height:18,background:LIME,transformOrigin:'left',transform:`scaleX(${ramp(f,role.from,role.from+7)})`}}/>}<span style={{position:'relative'}}>{role.text}</span></span></div></Center>}
 {f>=192&&f<246&&<Center opacity={1-ramp(f,242,246)}>{copy.summary.map((line,i)=><Typed key={line.text} line={line} size={i===0?99:83} nextStart={copy.summary[i+1]?.start}/>)}</Center>}
 {f>=246&&<Center opacity={ramp(f,246,252)} y={(1-ramp(f,246,258))*8}><Logo/></Center>}
 <Audio src={staticFile('sound.wav')}/>
 </AbsoluteFill>;
};
export const KHTypeCover=()=> <AbsoluteFill style={{color:INK,fontFamily:'KH, sans-serif'}}><Fonts/><Paper/><div style={{position:'absolute',left:70,right:70,top:90,textAlign:'center'}}><Logo size={38}/></div><Center><div style={{fontSize:112,fontWeight:780,lineHeight:1.12,letterSpacing:-3.5}}>Vaše značka.<br/>Náš obsah.</div><div style={{width:100,height:5,background:LIME,margin:'32px auto 0'}}/></Center><div style={{position:'absolute',left:70,right:70,bottom:105,textAlign:'center',fontSize:25,fontWeight:570,letterSpacing:1}}>UGC PRO VAŠI ZNAČKU.</div></AbsoluteFill>;
export const Root=()=> <><Composition id="KHTypeCZ" component={KHTypeCZ} width={1080} height={1920} fps={30} durationInFrames={288}/><Composition id="KHTypeCover" component={KHTypeCover} width={1080} height={1350} fps={30} durationInFrames={1}/></>;
