import React from 'react';
import {Composition} from 'remotion';
import {KHStudioReelV3} from './reel';
export const Root: React.FC = () => <Composition id="KHStudioReelV3" component={KHStudioReelV3} durationInFrames={372} fps={30} width={1080} height={1920}/>;
