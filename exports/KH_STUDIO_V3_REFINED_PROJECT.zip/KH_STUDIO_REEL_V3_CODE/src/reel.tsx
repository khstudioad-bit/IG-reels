import React from 'react';
import {AbsoluteFill, Easing, interpolate, OffthreadVideo, staticFile, useCurrentFrame} from 'remotion';

const BG = '#111315', CREAM = '#F4F3EF', LIME = '#D5FF70';
const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};
const bezier = Easing.bezier(0.22, 1, 0.36, 1);
const travel = Easing.bezier(0.65, 0, 0.25, 1);
const ramp = (f: number, a: number, b: number, easing = bezier) => interpolate(f, [a, b], [0, 1], {...clamp, easing});
const lerp = (a: number, b: number, t: number) => a + (b-a)*t;

export const KHStudioReelV3: React.FC = () => {
  const f = useCurrentFrame();
  const settle = ramp(f, 0, 45);
  const grow = ramp(f, 78, 128, travel);
  const shrink = ramp(f, 272, 316, travel);
  const shell = 1 - grow + shrink;
  const width = lerp(600, 1080, grow) - shrink * 540;
  const height = width * 16 / 9;
  const left = (1080-width)/2 + 30*(1-settle)*(1-grow);
  const top = lerp(578 + 24*(1-settle), 0, grow) + shrink*404;
  const radius = 28*shell;
  const rotation = (-2.4*(1-settle) + Math.sin(f/42)*0.48)*shell;
  const tilt = (-6*(1-settle) + Math.sin(f/63)*1.3)*shell;
  const pitch = 1.7*(1-settle)*shell;
  const opening = 1-ramp(f, 57, 78);
  const closing = ramp(f, 320, 342);
  const brand = Math.max(1-ramp(f, 75, 93), ramp(f, 315, 335));
  const floorY = Math.min(1830, top+height+28);

  return <AbsoluteFill style={{background:BG, color:CREAM, fontFamily:'KH, sans-serif', overflow:'hidden'}}>
    <style>{`@font-face{font-family:KH;src:url('${staticFile('fonts/DejaVuSans-Bold.ttf')}');font-weight:700}@font-face{font-family:KH;src:url('${staticFile('fonts/DejaVuSans.ttf')}');font-weight:400}*{box-sizing:border-box}`}</style>
    {/* Scene lighting and floor remain behind the moving video plane. */}
    <AbsoluteFill style={{background:'radial-gradient(ellipse at 55% 51%, #252925 0%, #191c1b 34%, #111315 70%)', opacity:shell}}/>
    <div style={{position:'absolute',left:-180+30*settle,top:floorY-22,width:1440,height:2,background:'linear-gradient(90deg,transparent,#f4f3ef0d,transparent)',opacity:shell*0.7}}/>
    <div style={{position:'absolute',left:left-45,top:floorY-18,width:width+90,height:55,borderRadius:'50%',background:'#000',filter:'blur(24px)',transform:`scaleX(${lerp(.8,1,settle)})`,opacity:shell*.52}}/>
    <div style={{position:'absolute',left:left+width*.12,top:floorY+15,width:width*.76,height:70,borderRadius:'50%',background:'radial-gradient(ellipse,#f4f3ef12,transparent 72%)',filter:'blur(14px)',opacity:shell}}/>

    <div style={{position:'absolute',left:76,right:76,top:154,display:'flex',alignItems:'center',justifyContent:'space-between',opacity:brand}}>
      <div style={{fontSize:31,fontWeight:700,letterSpacing:-1.5}}>KH<span style={{color:LIME,margin:'0 7px'}}>/</span>STUDIO</div>
      <div style={{fontSize:16,fontWeight:400,letterSpacing:3,color:'#acaeaa'}}>MOTION DESIGN</div>
    </div>

    <div style={{position:'absolute',left:76,top:272,opacity:opening,transform:`translateY(${lerp(26,0,ramp(f,0,27))-ramp(f,57,78)*25}px)`}}>
      <div style={{fontSize:83,fontWeight:700,letterSpacing:-5.8,lineHeight:1.02}}>PRODUKTOVÉ</div>
      <div style={{fontSize:100,fontWeight:700,letterSpacing:-6.5,lineHeight:1.03}}>ANIMACE<span style={{color:LIME}}>.</span></div>
    </div>

    {/* Aspect ratio stays exactly 9:16 through the complete transform. */}
    <div style={{position:'absolute',left,top,width,height,transformOrigin:'50% 65%',transform:`perspective(2400px) rotateX(${pitch}deg) rotateY(${tilt}deg) rotateZ(${rotation}deg)`,borderRadius:radius,boxShadow:`${lerp(-14,0,settle)*shell}px ${36*shell}px ${76*shell}px #0009`}}>
      <div style={{position:'absolute',inset:0,borderRadius:radius,overflow:'hidden',background:'#090b0b'}}>
        <OffthreadVideo src={staticFile('source.mp4')} muted style={{display:'block',width:'100%',height:'100%',objectFit:'contain'}}/>
        <div style={{position:'absolute',inset:0,borderRadius:radius,boxShadow:`inset 0 0 0 ${shell}px #f4f3ef35`,pointerEvents:'none'}}/>
      </div>
      {/* Edge light belongs to the frame, never across the product picture. */}
      <div style={{position:'absolute',top:0,left:radius,width:width-radius*2,height:1,background:'linear-gradient(90deg,transparent,#f4f3ef80,transparent)',opacity:shell*.7}}/>
    </div>

    {/* Text returns only after the video has cleared the closing safe zone. */}
    <div style={{position:'absolute',left:76,right:110,top:1430,opacity:closing,transform:`translateY(${24*(1-closing)}px)`}}>
      <div style={{width:38,height:3,background:LIME,marginBottom:26}}/>
      <div style={{fontSize:60,fontWeight:700,letterSpacing:-3.1,lineHeight:1.12}}>Máte produkt?<br/>Pojďme ho rozhýbat.</div>
      <div style={{fontSize:20,letterSpacing:2.4,fontWeight:400,color:'#b9bcb6',marginTop:26}}>SPOLUPRÁCE PŘES ZPRÁVY ↗</div>
    </div>
  </AbsoluteFill>;
};
