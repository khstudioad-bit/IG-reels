const {bundle}=require('@remotion/bundler');
const {selectComposition,renderStill,openBrowser}=require('@remotion/renderer');
const path=require('path');const fs=require('fs');
(async()=>{
 const tag=process.argv[2]||'pass1';const output=path.resolve('out',tag);fs.mkdirSync(output,{recursive:true});
 const url=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});
 const browser=await openBrowser('chrome',{browserExecutable:process.env.CHROME_PATH||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined)});
 try{
 const comp=await selectComposition({serveUrl:url,id:'KHStudioReelV3',puppeteerInstance:browser});
 for(const frame of [20,60,100,140,210,285,340]){
  await renderStill({serveUrl:url,composition:comp,frame,output:path.join(output,`${frame}.jpg`),imageFormat:'jpeg',jpegQuality:88,puppeteerInstance:browser});
  console.log(`Reviewed frame ${frame}`);
 }
 }finally{await browser.close({silent:true});}
})().catch(e=>{console.error(e);process.exit(1)});
