import {Config} from '@remotion/cli/config';
import {existsSync} from 'node:fs';
const browser = process.env.CHROME_PATH || (existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
if (browser) Config.setBrowserExecutable(browser);
Config.setConcurrency(3);
Config.setPixelFormat('yuv420p');
Config.setColorSpace('bt709');
