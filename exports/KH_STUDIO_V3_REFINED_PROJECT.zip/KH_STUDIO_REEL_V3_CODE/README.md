# KH Studio Reel V3 — refined edition

A continuous 1080 × 1920, 30 fps, 372-frame (12.4-second) Remotion composition. Uses the exact `public/source.mp4` supplied in the uploaded V3 project; it is never replaced, stretched, or cropped by the outer composition.

## Run

Node.js 20+ and npm. Install Chrome/Chromium or allow Remotion to obtain its supported browser. In this cloud environment `/usr/bin/chromium` is detected automatically. Set `CHROME_PATH` only to use another installed browser.

```sh
npm install
npm run dev
```

For repeatable installation after the first install, use `npm ci` with the included lockfile.

```sh
npm run check
npm run render
npm run cover
npm run review -- pass2
```

- MP4: `out/KH_REEL_V3.mp4` (H.264, yuv420p, BT.709; final delivered export is named `KH_REEL_V3_REFINED.mp4`)
- Cover: `out/cover.png` (frame 18)
- Review frames: `out/pass2/{20,60,100,140,210,285,340}.jpg`
- Source: `src/reel.tsx`; composition settings: `src/root.tsx`.

## Design

The picture remains on one continuous moving plane: a subtle perspective settle, a full-screen reveal timed to the supplied product sequence, then a return to a smaller branded frame. Its dimensions retain the original 9:16 ratio throughout. Shadows and edge highlights track the plane; restrained background lighting provides depth. A neutral matte background replaces the original grid and unrelated color gradients.

Typography lives outside the video in the framed sections. It clears before expansion and returns after contraction. Czech copy describes the service and invites contact, without invented campaign results, registered-trademark symbols, or a “REEL” keyword CTA. Branding uses #111315, #F4F3EF and #D5FF70. Embedded type already present in the supplied source remains unchanged.

## Audio and assets

The input is silent. This delivery is also silent: no commercially licensed audio was included, and the earlier brief asked for no music. No third-party audio, synthetic replacement music, or unverified sound-effect assets were added. Sound design can be added after suitable assets and their commercial license terms are supplied.

Bundled DejaVu fonts are licensed for commercial use; their copyright and license notice is included in `public/fonts/LICENSE.txt`. The supplied video remains user-provided media; this project does not establish its licensing provenance.

## Review

Two visual passes were rendered and inspected at the seven frame positions requested in AGENTS.md. Pass two reduces the opening frame size and raises it above the lower interface area, removes a low footer, applies perspective to the moving plane, shortens contraction, and raises the closing text. The first pass MP4 and review frames are retained in the cloud workspace for comparison.
