from pathlib import Path
import subprocess,json,wave,numpy as np
root=Path(__file__).resolve().parents[1];pub=root/'public';cfg=json.loads((root/'edit.json').read_text());fps=cfg['fps'];cuts=cfg['cuts']
def run(args):subprocess.run(args,check=True,cwd=root)
g=[];vlabels=[];alabels=[]
for i,c in enumerate(cuts):
 n=c['frames'];dur=n/fps;start=c['start'];r=c['rate'];end=start+dur*r
 g.append(f'[0:v]trim=start={start}:end={end},setpts=(PTS-STARTPTS)/{r},fps={fps},tpad=stop_mode=clone:stop_duration=0.1,trim=end_frame={n},setpts=N/({fps}*TB)[v{i}]')
 # No speech is sped up. The only speed change is in the silent towel transition.
 a=f'[0:a]atrim=start={start}:end={end},asetpts=PTS-STARTPTS'
 if r!=1:a+=f',atempo={r}'
 a+=f',aresample=48000,apad,atrim=duration={dur},afade=t=in:st=0:d=0.004,afade=t=out:st={max(0,dur-.004)}:d=0.004[a{i}]'
 g.append(a);vlabels.append(f'[v{i}]');alabels.append(f'[a{i}]')
nh=cfg['end_hold_frames'];hold=nh/fps
start=cfg['end_hold_source_time']
g.append(f'[0:v]trim=start={start}:end={start+1/12},setpts=PTS-STARTPTS,fps={fps},tpad=stop_mode=clone:stop_duration={hold+.1},trim=end_frame={nh},setpts=N/({fps}*TB)[vh]')
g.append(f'anullsrc=r=48000:cl=stereo,atrim=duration={hold}[ah]')
g.append(''.join(vlabels)+f'[vh]concat=n={len(cuts)+1}:v=1:a=0,eq=contrast=1.012:brightness=0.002:saturation=0.985[v]')
g.append(''.join(alabels)+f'[ah]concat=n={len(cuts)+1}:v=0:a=1,highpass=f=75,lowpass=f=14000,acompressor=threshold=0.15:ratio=1.6:attack=12:release=160:makeup=1.1[a]')
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(pub/'source.mp4'),'-filter_complex',';'.join(g),'-map','[v]','-an','-c:v','libx264','-crf','16','-preset','medium','-pix_fmt','yuv420p',str(pub/'edit-picture.mp4'),'-map','[a]','-vn','-c:a','pcm_s16le',str(pub/'dialogue-unmastered.wav')])
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(start),'-i',str(pub/'source.mp4'),'-frames:v','1',str(pub/'poster.png')])
# Voice normalization is deliberately separate from the original music stem.
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(pub/'dialogue-unmastered.wav'),'-af','loudnorm=I=-16:TP=-2:LRA=9','-ar','48000',str(pub/'dialogue.wav')])
sr=48000;duration=15;t=np.arange(sr*duration)/sr;rng=np.random.default_rng(27)
# Original restrained instrumental: warm sustained tones and a very soft muted pulse.
music=np.zeros_like(t)
for beat in np.arange(0,15,3):
 q=t-beat;m=(q>=0)&(q<4.5);z=q[m];env=np.minimum(z/.3,1)*np.exp(-z*.65)
 for hz,amp in [(146.832,.36),(220,.20),(261.626,.12)]:
  music[m]+=amp*np.sin(2*np.pi*hz*z+.06*np.sin(2*np.pi*.21*z))*env
for k,beat in enumerate(np.arange(0,15,.6)):
 q=t-beat;m=(q>=0)&(q<.48);z=q[m];hz=[440,523.251,659.255,523.251][k%4]
 music[m]+=.14*np.sin(2*np.pi*hz*z)*np.exp(-z*11)*np.minimum(z/.006,1)
music*=np.minimum(t/.25,1)*np.clip((15-t)/.8,0,1)
with wave.open(str(pub/'dialogue.wav')) as w:
 voice=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,w.getnchannels()).mean(axis=1).astype(float)/32768
voice=np.pad(voice,(0,max(0,len(t)-len(voice))))[:len(t)]
cs=np.concatenate([[0],np.cumsum(np.pad(voice**2,(2400,2400)))]);env=np.sqrt((cs[4800:]-cs[:-4800])[:len(t)]/4800)
duck=1-.62*np.clip(env/.10,0,1)
# Music stays well beneath dialogue, with no sampled music or third-party SFX.
music=music/max(abs(music).max(),1e-6)*.065*duck
stereo=np.stack([music,np.roll(music,37)*.97],axis=1)
with wave.open(str(pub/'music-original.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((stereo*32767).astype('<i2').tobytes())
run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(pub/'dialogue.wav'),'-i',str(pub/'music-original.wav'),'-filter_complex','[0:a][1:a]amix=inputs=2:normalize=0,alimiter=limit=0.891:level=false,afade=t=out:st=14.75:d=0.25[m]','-map','[m]','-ar','48000',str(pub/'mix.wav')])
print('Prepared exact 450-frame picture and 15-second voice-first mix.')

probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','json',str(pub/'edit-picture.mp4')]))
assert int(probe['streams'][0]['nb_read_frames'])==450, probe
