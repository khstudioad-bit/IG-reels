# Final review

- Main and alternate rendered successfully at 1080 × 1920, H.264 / yuv420p / BT.709, 30 fps, 450 video frames (15.000 seconds).
- Both have 48 kHz stereo AAC. The MP4 container reports 15.019 seconds because of AAC packet padding; the picture is exactly 15.000 seconds.
- Both fully decoded with FFmpeg without errors. Fast-start MP4 atom order was verified (moov before mdat).
- Cover rendered at exactly 1080 × 1350 (4:5); face and bottle label were checked against title placement.
- Sampled the main timeline at frames 0, 70, 135, 188, 240, 290, 342, 375, 420 and 449, plus the alternate hook at frame 30. Inspected framing, useful gestures, label placement, type contrast and end hold.
- Full speech transcription and edited-mix transcription matched: “Why does my freshly washed hair still look sad? Watch what one pump does. Okay, that shine. Smooth, glossy, and it still feels light. I'm obsessed.”
- Speech is at original speed; the only speed change is in a silent towel transition. The existing final product pose is held under the outro, after the last spoken sentence.
- Caption timing was refined before final render: “That shine” waits until after the “Okay” and pause. End CTA size was increased for mobile readability.
- Encoded final audio measured -15.4 LUFS integrated, 4.7 LU loudness range, -1.9 dB true peak. Added instrumental is original synthesis and stays ducked under speech. No copied track or third-party samples were added.
- TypeScript passed. The complete prepare-media command was re-executed in an isolated temporary project and successfully regenerated 450 video frames plus a 15-second mix. The original source hash is unchanged.
- No claim about actual sales, conversion uplift or a client relationship is added. Overlay product phrases are from the source dialogue.
