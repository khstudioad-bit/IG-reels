# Frame plan (30 fps)

0–59: start inside the opening question, no silent lead-in; hook visible on the first frame.
60–84: tighter reframe for the question's final word; long internal pause removed.
85–99: “Watch”; keep the useful hand gesture.
100–173: one-pump demonstration; preserve face, hand and product. Caption appears at 112.
174–201: accelerate only the non-speaking towel transformation.
202–259: reveal and “Okay, that shine”; emphasize the latter phrase from 228.
260–358: smooth/glossy/light spoken result; allow the original bottle close-up to lead.
359–385: original “I'm obsessed” performance; modest KH Studio service message enters.
386–404: brief hold on the final product pose, restrained moving reframe.
405–449: branded overlay and DM CTA. No speech is cut off by the outro.

All speech kept at original speed. All added claims describe KH Studio's offered service or quote the source speech. Source product label and face are not covered by added type. The alternate version changes the opening headline only.
