import React from 'react';
import {AbsoluteFill,Audio,Composition,Easing,Img,interpolate,OffthreadVideo,staticFile,useCurrentFrame} from 'remotion';
import edit from '../edit.json';
const BG='#111315',CREAM='#F4F3EF',LIME='#D5FF70';
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const ease=Easing.bezier(.2,.8,.2,1);
const ramp=(f:number,a:number,b:number)=>interpolate(f,[a,b],[0,1],{...clamp,easing:ease});
const Fonts=()=> <style>{`@font-face{font-family:InterTight;src:url('${staticFile('fonts/InterTight.ttf')}');font-weight:100 900}*{box-sizing:border-box}`}</style>;
const TextBeat:React.FC<{from:number;to:number;children:React.ReactNode;top?:number;size?:number}>=({from,to,children,top=1390,size=79})=>{
 const f=useCurrentFrame();const p=ramp(f,from,from+6);const out=ramp(f,to-4,to);
 if(f<from||f>=to)return null;
 return <div style={{position:'absolute',left:76,right:140,top,opacity:p*(1-out),transform:`translateY(${(1-p)*14-out*5}px)`,fontSize:size,fontWeight:730,lineHeight:1.02,letterSpacing:-1.7,textShadow:'0 2px 16px #11131580'}}>{children}</div>
};
export const KHUGC:React.FC<{alternate?:boolean}>=({alternate=false})=>{
 const f=useCurrentFrame();const hook=1-ramp(f,74,85);const proof=ramp(f,359,366)*(1-ramp(f,399,405));const end=ramp(f,405,414);
 const zoom=f<60?1.035:f<85?1.065:f<174?1:f<202?1:f<260?1.025:f<359?1:f<386?1:interpolate(f,[386,450],[1,1.018],clamp);
 return <AbsoluteFill style={{background:BG,color:CREAM,fontFamily:'InterTight, sans-serif'}}><Fonts/>
 <AbsoluteFill style={{overflow:'hidden'}}><OffthreadVideo muted src={staticFile('edit-picture.mp4')} style={{width:'100%',height:'100%',objectFit:'cover',transform:`scale(${zoom})`,transformOrigin:'50% 34%'}}/></AbsoluteFill>
 <div style={{position:'absolute',inset:0,background:'linear-gradient(180deg,#11131540 0%,transparent 19%,transparent 53%,#1113152e 64%,#111315d4 87%,#111315ee 100%)',pointerEvents:'none'}}/>
 <div style={{position:'absolute',left:76,top:150,opacity:hook,fontSize:26,fontWeight:760,letterSpacing:-.4}}>KH<span style={{color:LIME,margin:'0 5px'}}>/</span>STUDIO<span style={{fontSize:12,verticalAlign:'super'}}>®</span></div>
 <div style={{position:'absolute',left:76,right:130,top:alternate?1248:1280,opacity:hook,transform:`translateY(${(1-ramp(f,0,7))*12}px)`}}>
 {alternate?<><div style={{fontSize:24,letterSpacing:3,fontWeight:620,marginBottom:13}}>FRESHLY WASHED.</div><div style={{fontSize:117,lineHeight:.93,fontWeight:820,letterSpacing:-4}}>STILL<br/>LOOKS <span style={{color:LIME}}>SAD?</span></div></>:<><div style={{fontSize:72,lineHeight:1.05,fontWeight:650,letterSpacing:-2}}>Freshly washed.</div><div style={{fontSize:91,lineHeight:1.07,fontWeight:780,letterSpacing:-3}}>Still looks <span style={{color:LIME}}>sad?</span></div></>}
 </div>
 {edit.captions.map(c=><TextBeat key={c.from} from={c.from} to={c.to} size={c.text.length>14?70:85}>{c.text}</TextBeat>)}
 <div style={{position:'absolute',left:76,right:130,top:1375,opacity:proof,transform:`translateY(${(1-ramp(f,359,366))*12}px)`}}><div style={{width:34,height:3,background:LIME,marginBottom:22}}/><div style={{fontSize:62,fontWeight:720,lineHeight:1.03,letterSpacing:-1.6}}>UGC made for<br/>modern brands.</div></div>
 <div style={{position:'absolute',inset:0,background:'linear-gradient(transparent 58%,#11131525 66%,#111315d9 81%,#111315 100%)',opacity:end}}/>
 <div style={{position:'absolute',left:76,right:135,top:1380,opacity:end,transform:`translateY(${(1-end)*16}px)`}}>
 <div style={{fontSize:60,fontWeight:800,letterSpacing:-2}}>KH<span style={{color:LIME,margin:'0 5px'}}>/</span>STUDIO<span style={{fontSize:21,verticalAlign:'super'}}>®</span></div>
 <div style={{fontSize:38,fontWeight:520,lineHeight:1.14,letterSpacing:-.4,marginTop:18}}>UGC ads for brands<br/>that want attention.</div>
 <div style={{display:'inline-block',fontSize:38,fontWeight:650,color:LIME,marginTop:26,paddingBottom:5,borderBottom:`2px solid ${LIME}`}}>DM us ↗</div>
 </div>
 <Audio src={staticFile('mix.wav')}/>
 </AbsoluteFill>;
};
export const KHUGCCover=()=> <AbsoluteFill style={{background:BG,color:CREAM,fontFamily:'InterTight, sans-serif',overflow:'hidden'}}><Fonts/>
 <Img src={staticFile('poster.png')} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:'50% 8%'}}/>
 <div style={{position:'absolute',top:720,left:0,bottom:0,width:790,background:'linear-gradient(90deg,#111315e0,#111315a6 70%,transparent)',maskImage:'linear-gradient(transparent,black 25%)'}}/>
 <div style={{position:'absolute',left:70,top:70,fontSize:33,fontWeight:800,color:BG,letterSpacing:-1}}>KH/STUDIO<span style={{fontSize:14,verticalAlign:'super'}}>®</span></div>
 <div style={{position:'absolute',left:70,top:948}}><div style={{width:35,height:4,background:LIME,marginBottom:24}}/><div style={{fontSize:105,lineHeight:.96,fontWeight:800,letterSpacing:-3}}>UGC.<br/>FOR BRANDS.</div><div style={{fontSize:20,letterSpacing:3,fontWeight:550,marginTop:29}}>BEAUTY / SOCIAL ADS</div></div>
 </AbsoluteFill>;
export const Root=()=> <><Composition id="KHUGC" component={KHUGC} width={1080} height={1920} fps={30} durationInFrames={450}/><Composition id="KHUGCAlt" component={KHUGC} defaultProps={{alternate:true}} width={1080} height={1920} fps={30} durationInFrames={450}/><Composition id="KHUGCCover" component={KHUGCCover} width={1080} height={1350} fps={30} durationInFrames={1}/></>;
