# KH Studio service ad — review

The entire creative advertises KH Studio's services. The opening says “Tvoříme reklamy”; the body names UGC ads, product animation and motion design; the ending lists the same services with “Napište nám”. Source product dialogue and earlier English product captions are absent. The source videos function as portfolio images.

Motion: moving live-video portfolio planes, full-screen UGC expansion, a three-strip wipe into the product sequence, product-plane contraction revealing motion-design type, a drawn lime path, crossing live-video planes into a portfolio pair, and an identity reveal behind departing planes. Czech type uses masks and controlled easing throughout. Product and UGC source aspect ratios stay 9:16.

Reviewed stills across the timeline: 0, 28, 55, 95, 126, 155, 205, 242, 275, 320, 355, 400, 430 and 449. After the first pass, replaced the generic motion-design kicker with “Typografie / Střih / Pohyb”, adjusted the mini UGC playback speed to remain within its source duration, and increased the music master by 3 dB. A restrained cream fade was added behind the product-animation service title so dark fruit cannot impair its contrast. Final encoded frames were reviewed again at 0, 70, 126, 155, 205, 275, 355 and 430.

Validated final MP4: 1080 × 1920, H.264 / yuv420p / BT.709, 30 fps, 450 frames, 15.000-second picture with stereo AAC. Complete FFmpeg decoding passed. Feed cover is 1080 × 1350. TypeScript passed. Source sound is muted in every video plane; only the original synthesized beat and timed sound design are used.
