# KH Studio — reklama služeb

15-second vertical service advertisement for KH Studio. The message throughout is the studio's services: UGC ads, product animation and motion design. Existing footage is used as portfolio imagery, with original product dialogue muted.

## Open / render

Node.js 20+ and npm. Prepared sound and all media are included.

```sh
npm ci
npm run dev
npm run check
npm run render
npm run cover
```

- `out/KH_STUDIO_SLUZBY_15.mp4`: 1080 × 1920, 30 fps, 450 frames, H.264/AAC, BT.709.
- `out/KH_STUDIO_SLUZBY_COVER.png`: 1080 × 1350 feed cover, 4:5.
- `src/reel.tsx`: editable composition, Czech copy and keyframe timing.
- `public/ugc.mp4`: user-supplied clean UGC footage.
- `public/product.mp4`: user's existing product commercial.
- `public/sound.wav`: original 120 BPM instrumental and timed transformation cues.

Chromium at `/usr/bin/chromium` is detected in this environment. Elsewhere Remotion uses its supported browser. `CHROME_PATH` optionally selects another browser.

## Timeline at 30 fps

0–44: “Tvoříme reklamy.” Two live portfolio planes, moving into the UGC reveal.
45–119: “UGC reklamy.” Full-screen creator footage and concise studio service copy.
120–136: outgoing UGC separates into three moving strips, exposing product animation.
137–224: “Produktové animace.” Original can explosion / liquid commercial at 1.2×, with studio service type.
225–254: product plane contracts, revealing motion-design type behind it.
255–314: “Motion design.” Connected live video planes, animated typography and a drawn lime path.
315–389: moving planes cross and reform into the two-part portfolio; studio service summary.
390–449: planes depart and reveal KH Studio, all three service names and “Napište nám”.

The original UGC product statements and earlier product captions are absent. No invented client relationship, performance metrics or new product claims are added.

## Audio / assets

Only the supplied images in motion are used; source dialogue is muted. Sound was synthesized for this project from oscillators and filtered noise without copied recordings, third-party samples or an external song. To regenerate it, install Python, NumPy, SciPy and FFmpeg and run `npm run audio`. Rendering normally uses the included sound file and needs no Python.

Inter Tight is bundled with its SIL Open Font License in `public/fonts/OFL.txt`. Source videos are the user's supplied media. The 720p source pictures are upscaled; typography and graphics render at 1080p. No beauty retouching or synthetic product-label changes are applied.
