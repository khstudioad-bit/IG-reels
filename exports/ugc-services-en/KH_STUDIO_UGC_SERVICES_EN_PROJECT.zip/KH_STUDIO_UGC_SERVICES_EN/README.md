# KH Studio — English UGC services ad

15-second English Instagram Reel advertising KH Studio's UGC services. It retains the approved moving-panel composition, split-strip wipe, kinetic typography, connected transitions and original sound design.

## Run

Node.js 20+ and npm. Media, fonts and mastered sound are included.

```sh
npm ci
npm run dev
npm run check
npm run render
npm run cover
```

- `out/KH_STUDIO_UGC_SERVICES_EN_15.mp4`: 1080 × 1920, 30 fps, 450 frames, H.264/AAC, BT.709.
- `out/KH_STUDIO_UGC_SERVICES_EN_COVER.png`: 1080 × 1350 (4:5) feed cover.
- `src/reel.tsx`: editable English copy, frame boundaries, easing, layouts and media in-points.
- `public/ugc.mp4`: the sole video source, the user's supplied UGC footage.
- `public/sound.wav`: original instrumental and frame-timed transition cues.

The source dialogue remains muted, as in the approved montage; the English message is carried by the studio's typography. Source product-benefit dialogue is not used as the studio's sales copy.

A local `/usr/bin/chromium` is detected when present. Otherwise Remotion selects its supported browser; `CHROME_PATH` can select a custom installed browser.

## Message and timeline

0–44: “WE MAKE UGC ADS.” / “CONCEPT • CONTENT • EDIT”.
45–119: “CREATOR-LED UGC ADS.” Live UGC expands to full screen.
120–136: split-strip transition between two moments of the same supplied UGC footage.
137–224: “PRODUCT DEMOS.” Original product-handling footage illustrates a UGC format.
225–314: “EDITED FOR SOCIAL.” Pace, captions and branding; picture contracts into the moving layout.
315–389: “UGC FOR YOUR BRAND.” Two UGC views form the portfolio layout; “From first idea to final edit.”
390–449: KH Studio identity; creative concepts, product demos, editing and captions; “DM us”.

Only UGC video is referenced or included. All visible headlines, supporting text and CTA are English. Original aspect ratio is preserved through the plane transforms. No new product claims, testimonials or performance metrics are added.

## Assets / audio

Inter Tight is included with its SIL Open Font License in `public/fonts/OFL.txt`. Footage is user-supplied. The source is 720p; the export upscales it and renders typography natively at 1080p, without synthetic retouching.

Instrumental and transition cues were synthesized from code for this project, without a copied song or third-party samples. To regenerate sound, install Python, NumPy, SciPy and FFmpeg and run `npm run audio`. Normal rendering uses the included sound asset and requires no Python.
