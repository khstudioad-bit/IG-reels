import React from 'react';
import {AbsoluteFill,Audio,Composition,Easing,interpolate,OffthreadVideo,Sequence,staticFile,useCurrentFrame} from 'remotion';
const BG='#111315',CREAM='#F4F3EF',LIME='#D5FF70';
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const ease=Easing.bezier(.2,.86,.22,1), travel=Easing.bezier(.72,0,.22,1);
const p=(f:number,a:number,b:number,e= ease)=>interpolate(f,[a,b],[0,1],{...clamp,easing:e});
const l=(a:number,b:number,t:number)=>a+(b-a)*t;
const Fonts=()=> <style>{`@font-face{font-family:InterTight;src:url('${staticFile('fonts/InterTight.ttf')}');font-weight:100 900}*{box-sizing:border-box}`}</style>;
const Logo:React.FC<{size?:number}>=({size=31})=><div style={{fontSize:size,fontWeight:800,letterSpacing:-size*.035,whiteSpace:'nowrap'}}>KH<span style={{color:LIME,margin:'0 .045em'}}>/</span>STUDIO<span style={{fontSize:'.32em',verticalAlign:'super',letterSpacing:0}}>®</span></div>;
const Film:React.FC<{src:string;from:number;start:number;rate?:number}>=({src,from,start,rate=1})=><Sequence from={from} layout="none"><OffthreadVideo muted src={staticFile(src)} startFrom={Math.round(start*30)} playbackRate={rate} style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:'cover'}}/></Sequence>;
const Lines:React.FC<{lines:string[];from:number;size:number;line?:number;color?:string}>=({lines,from,size,line=.94,color=CREAM})=>{const f=useCurrentFrame();return <div style={{fontSize:size,lineHeight:line,letterSpacing:-size*.045,fontWeight:800,color}}>{lines.map((s,i)=><div key={s} style={{overflow:'hidden',paddingBottom:8,marginBottom:-8}}><div style={{transform:`translateY(${l(110,0,p(f,from+i*3,from+14+i*3))}%)`}}>{s}</div></div>)}</div>};
const Frame:React.FC<{x:number;y:number;w:number;r:number;angle?:number;children:React.ReactNode;opacity?:number}>=({x,y,w,r,angle=0,children,opacity=1})=><div style={{position:'absolute',left:x,top:y,width:w,height:w*16/9,borderRadius:r,overflow:'hidden',transform:`rotate(${angle}deg)`,boxShadow:r?'0 30px 70px #0008':'none',opacity,background:BG}}>{children}<div style={{position:'absolute',inset:0,borderRadius:r,boxShadow:r?'inset 0 0 0 1px #f4f3ef36':'none',pointerEvents:'none'}}/></div>;
export const KHUGCServicesEN=()=>{
 const f=useCurrentFrame(); const g=p(f,30,60,travel), collapse=p(f,225,255,travel), mosaic=p(f,305,335,travel), exit=p(f,385,410,travel);
 const open=1-p(f,28,44), ugcText=p(f,57,68)*(1-p(f,111,122));
 const px=l(0,86,collapse)+(560-86)*mosaic+exit*800;
 const py=l(0,630,collapse)+20*mosaic+exit*130;
 const pw=l(1080,530,collapse)+(444-530)*mosaic;
 const mx=l(750,690,p(f,251,269))+(76-690)*mosaic-exit*620;
 const my=l(950,910,p(f,251,269))+(650-910)*mosaic+exit*100;
 const mw=280+(444-280)*mosaic;
 const end=p(f,395,413);
 return <AbsoluteFill style={{background:BG,color:CREAM,fontFamily:'InterTight, sans-serif',overflow:'hidden'}}><Fonts/>
 <AbsoluteFill style={{background:'radial-gradient(ellipse at 58% 56%,#242824 0%,#111315 62%)'}}/>
 {/* Motion-design type is revealed by the retreating product plane. */}
 {f>=225&&f<319&&<div style={{position:'absolute',left:76,top:240,opacity:1-p(f,299,315)}}><div style={{fontSize:23,letterSpacing:4,color:LIME,marginBottom:22}}>PACE / CAPTIONS / BRANDING</div><Lines lines={['EDITED','FOR SOCIAL.']} from={231} size={126}/></div>}
 {f>=120&&f<414&&<Frame x={px} y={py} w={pw} r={24*collapse} angle={-3.5*collapse*(1-mosaic)+exit*10}><Film src="ugc.mp4" from={120} start={3.65} rate={0.8}/></Frame>}
 {/* A moving UGC plane grows into the full screen from the opening portfolio. */}
 {f<120&&<Frame x={l(76+12*(1-p(f,0,25)),0,g)} y={l(645-15*p(f,0,25),0,g)} w={l(500,1080,g)} r={l(25,0,g)} angle={-4.5*(1-g)}><Film src="ugc.mp4" from={0} start={8.45}/></Frame>}
 {f<60&&<Frame x={l(652,1340,g)} y={l(775-35*p(f,0,32),620,g)} w={365} r={22} angle={6+g*9} opacity={1-p(f,40,58)}><Film src="ugc.mp4" from={0} start={3.75} rate={0.8}/></Frame>}
 {/* The outgoing UGC picture divides into three printed strips, exposing the product shot. */}
 {f>=120&&f<137&&[0,1,2].map(i=>{const q=p(f,120+i,133+i,travel);return <div key={i} style={{position:'absolute',left:i*360,top:0,width:361,height:1920,overflow:'hidden',transform:`translateY(${(i===1?-1:1)*q*2000}px)`}}><div style={{position:'absolute',left:-i*360,top:0,width:1080,height:1920}}><Film src="ugc.mp4" from={0} start={8.45}/></div><div style={{position:'absolute',left:0,top:0,width:2,height:'100%',background:LIME,opacity:.65}}/></div>})}
 {/* Intro service headline, visible on the very first frame. */}
 <div style={{position:'absolute',left:76,right:76,top:148,opacity:open,display:'flex',justifyContent:'space-between',alignItems:'center'}}><Logo/><div style={{fontSize:19,letterSpacing:3,color:'#bfc4ba'}}>UGC FOR BRANDS</div></div>
 <div style={{position:'absolute',left:76,top:264,opacity:open,transform:`translateY(${-p(f,28,44)*45}px)`}}><Lines lines={['WE MAKE']} from={-18} size={123}/><Lines lines={['UGC ADS.']} from={-15} size={160}/></div>
 <div style={{position:'absolute',left:76,top:1606,opacity:open,fontSize:27,letterSpacing:2,fontWeight:550}}>CONCEPT <span style={{color:LIME,margin:'0 16px'}}>•</span> CONTENT <span style={{color:LIME,margin:'0 16px'}}>•</span> EDIT</div>
 {/* Service name, not a shampoo product claim. */}
 {f>=45&&f<125&&<><div style={{position:'absolute',inset:0,background:'linear-gradient(transparent 50%,#111315a8 75%,#111315f2)',opacity:ugcText}}/><div style={{position:'absolute',left:76,top:1285,opacity:ugcText}}><Lines lines={['CREATOR-LED','UGC ADS.']} from={56} size={108}/><div style={{fontSize:29,marginTop:23,fontWeight:500}}>Content shaped around your brand.</div></div></>}
 {f>=137&&f<232&&<div style={{position:'absolute',inset:0,background:'linear-gradient(transparent 53%,#11131500 60%,#111315c2 80%,#111315f5 100%)',opacity:p(f,139,151)*(1-p(f,218,230))}}/>}
 {f>=137&&f<232&&<div style={{position:'absolute',left:76,top:1330,opacity:p(f,139,151)*(1-p(f,218,230)),color:CREAM}}><Lines lines={['PRODUCT','DEMOS.']} from={141} size={112} color={CREAM}/><div style={{fontSize:27,marginTop:22,fontWeight:550,letterSpacing:.3}}>Demos built around your product.</div></div>}
 {f>=248&&f<414&&<Frame x={mx} y={my} w={mw} r={20} angle={4*(1-mosaic)-exit*12} opacity={p(f,248,264)}><Film src="ugc.mp4" from={248} start={10.5} rate={0.75}/></Frame>}
 {f>=251&&f<317&&<svg width="1080" height="1920" style={{position:'absolute',opacity:1-p(f,297,315)}}><path d="M 79 584 L 79 660 Q 79 704 118 704 L 160 704" fill="none" stroke={LIME} strokeWidth="3" strokeDasharray="260" strokeDashoffset={260*(1-p(f,251,281))}/><circle cx="160" cy="704" r="6" fill={LIME} opacity={p(f,276,282)}/></svg>}
 {f>=310&&f<394&&<div style={{position:'absolute',left:76,top:260,opacity:p(f,310,326)*(1-p(f,381,394))}}><div style={{fontSize:22,letterSpacing:4,color:LIME,marginBottom:26}}>FOR YOUR BRAND.</div><Lines lines={['UGC FOR','YOUR BRAND.']} from={311} size={107}/></div>}
 {f>=319&&f<395&&<div style={{position:'absolute',left:76,top:1535,opacity:p(f,319,335)*(1-p(f,380,392)),fontSize:31,fontWeight:560,letterSpacing:.2}}>From first idea to final edit.</div>}
 {/* Final identity emerges behind the departing portfolio planes. */}
 <div style={{position:'absolute',left:76,right:76,top:550,opacity:end,transform:`translateY(${(1-end)*26}px)`}}><div style={{fontSize:23,letterSpacing:4,color:LIME,marginBottom:34}}>UGC CREATIVE FOR YOUR BRAND.</div><Logo size={111}/><div style={{fontSize:35,fontWeight:550,lineHeight:1.65,marginTop:44}}>CREATIVE CONCEPTS<br/>PRODUCT DEMOS<br/>EDITING & CAPTIONS</div><div style={{display:'inline-block',fontSize:47,fontWeight:680,color:LIME,marginTop:62,borderBottom:`3px solid ${LIME}`,paddingBottom:8}}>DM us ↗</div></div>
 <Audio src={staticFile('sound.wav')}/>
 </AbsoluteFill>;
};
export const KHUGCServicesENCover=()=> <AbsoluteFill style={{background:BG,color:CREAM,fontFamily:'InterTight, sans-serif',overflow:'hidden'}}><Fonts/><div style={{position:'absolute',left:76,top:90}}><Logo size={39}/></div><div style={{position:'absolute',left:76,top:250,fontWeight:800,fontSize:125,lineHeight:.91,letterSpacing:-5}}>WE MAKE<br/>UGC ADS<span style={{color:LIME}}>.</span></div><Frame x={90} y={550} w={390} r={22} angle={-4}><Film src="ugc.mp4" from={0} start={14.1}/></Frame><Frame x={635} y={645} w={300} r={20} angle={5}><Film src="ugc.mp4" from={0} start={4.7}/></Frame><div style={{position:'absolute',left:76,top:1260,fontSize:25,letterSpacing:1,fontWeight:600}}>CONCEPT • CONTENT • EDIT</div></AbsoluteFill>;
export const Root=()=> <><Composition id="KHUGCServicesEN" component={KHUGCServicesEN} width={1080} height={1920} fps={30} durationInFrames={450}/><Composition id="KHUGCServicesENCover" component={KHUGCServicesENCover} width={1080} height={1350} fps={30} durationInFrames={1}/></>;
