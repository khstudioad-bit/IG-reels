from pathlib import Path
import wave,numpy as np
root=Path(__file__).resolve().parents[1];sr=48000;t=np.arange(15*sr)/sr;s=np.zeros_like(t);rng=np.random.default_rng(710)
# Original 120 BPM electronic bed and transformation cues, no external samples.
for k,beat in enumerate(np.arange(0,15,.5)):
 q=t-beat;m=(q>=0)&(q<.35);z=q[m]
 s[m]+=.37*np.sin(2*np.pi*(48*z+7*(1-np.exp(-z*35))))*np.exp(-z*16)
 hz=[65.406,77.782,58.270,65.406][(k//8)%4]
 s[m]+=.15*np.sin(2*np.pi*hz*z)*np.minimum(z*95,1)*np.exp(-z*6)
for beat in np.arange(.25,15,.25):
 q=t-beat;m=(q>=0)&(q<.055);z=q[m];n=rng.normal(size=len(z));n=np.diff(n,prepend=0)
 s[m]+=.018*n*np.exp(-z*70)
for beat in [1.5,4,4.5,7.5,8.5,10.5,13,13.5]:
 q=t-(beat-.22);m=(q>=0)&(q<.38);z=q[m];n=rng.normal(size=len(z));from scipy.ndimage import gaussian_filter1d
 n=gaussian_filter1d(n,3)
 s[m]+=.15*n*np.sin(np.pi*z/.38)**2
 q=t-beat;m=(q>=0)&(q<.30);z=q[m]
 s[m]+=.23*np.sin(2*np.pi*(51*z+5*(1-np.exp(-z*40))))*np.exp(-z*18)
for k,beat in enumerate(np.arange(.5,15,.5)):
 q=t-beat;m=(q>=0)&(q<.36);z=q[m];hz=[261.626,311.127,391.995,349.228][k%4]
 s[m]+=.035*np.sin(2*np.pi*hz*z)*np.minimum(z*150,1)*np.exp(-z*10)
s=np.tanh(s*1.3)*.82;s*=np.minimum(t/.018,1)*np.clip((15-t)/.4,0,1)
stereo=np.stack([s,np.roll(s,9)*.985],axis=1)
with wave.open(str(root/'public/sound.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((stereo*32767).astype('<i2').tobytes())
print('15-second original beat with frame-timed transition cues.')
import subprocess
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(root/'public/sound.wav'),'-af','volume=3dB','-c:a','pcm_s16le',str(root/'public/sound-master.wav')],check=True)
(root/'public/sound-master.wav').replace(root/'public/sound.wav')
