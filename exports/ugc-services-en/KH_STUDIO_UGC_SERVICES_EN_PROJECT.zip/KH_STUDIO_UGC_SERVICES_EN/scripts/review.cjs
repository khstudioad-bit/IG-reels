const {bundle}=require('@remotion/bundler');
const {openBrowser,selectComposition,renderStill}=require('@remotion/renderer');
const fs=require('fs'),path=require('path');
(async()=>{
 const tag=process.argv[2]||'pass1';const out=path.resolve('review',tag);fs.mkdirSync(out,{recursive:true});
 const url=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});
 const executable=process.env.CHROME_PATH||(fs.existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
 const browser=await openBrowser('chrome',{browserExecutable:executable});
 try{
 for(const [id,frames] of [['KHUGCServicesEN',[0,28,55,95,126,155,205,242,275,320,355,400,430,449]],['KHUGCServicesENCover',[0]]]){
  const comp=await selectComposition({serveUrl:url,id,puppeteerInstance:browser});
  for(const frame of frames){await renderStill({serveUrl:url,composition:comp,frame,output:path.join(out,`${id}-${frame}.jpg`),imageFormat:'jpeg',jpegQuality:90,puppeteerInstance:browser});console.log(`${id} ${frame}`)}
 }
 }finally{await browser.close({silent:true})}
})().catch(e=>{console.error(e);process.exit(1)});
